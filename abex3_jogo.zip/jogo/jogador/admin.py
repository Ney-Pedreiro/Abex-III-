from django.contrib import admin
from .models import Jogador

admin.site.register(Jogador)